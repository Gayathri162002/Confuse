package com.capstone.Holiday.Controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    // Define endpoints for bookings
}
