package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.example.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUser(String user);
}
