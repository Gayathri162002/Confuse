package org.springframework.web.socket;

public class TextMessage {

}
