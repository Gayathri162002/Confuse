package org.springframework.web.socket.config.annotation;

public class EnableWebSocket {

}
