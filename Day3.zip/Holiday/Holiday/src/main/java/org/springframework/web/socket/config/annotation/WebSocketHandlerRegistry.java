package org.springframework.web.socket.config.annotation;

import com.example.handler.AvailabilityHandler;

public class WebSocketHandlerRegistry {

	public Object addHandler(AvailabilityHandler availabilityHandler, String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
